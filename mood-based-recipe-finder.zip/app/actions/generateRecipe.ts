"use server"

import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

type Preferences = {
  mealType: string
  mood: string
  ingredients: string
  selectedTools: string[]
}

export async function generateRecipe(preferences: Preferences) {
  try {
    const prompt = `Generate a concise recipe (maximum 1000 characters) based on the following preferences:
    Meal Type: ${preferences.mealType}
    Current Mood: ${preferences.mood}
    Available Ingredients: ${preferences.ingredients}
    Kitchen Tools: ${preferences.selectedTools.join(", ")}

    Please suggest a recipe that:
    1. Matches the meal type preference
    2. Is suitable for someone in the specified mood
    3. Uses the available ingredients (or suggests minimal additional ingredients)
    4. Can be prepared with the available kitchen tools
    
    Keep the response brief but informative. Format as follows:
    Recipe Name
    
    Description: [Brief description of why this matches preferences]
    
    Ingredients:
    - Ingredient 1
    - Ingredient 2
    
    Instructions:
    1. Step 1
    2. Step 2
    
    Estimated Time: X minutes
    `

    const { text } = await generateText({
      model: openai("gpt-3.5-turbo"),
      prompt,
      temperature: 0.7,
      maxTokens: 400, // Approximately 1000 characters
    })

    // Ensure response doesn't exceed 1000 characters
    const truncatedText = text.slice(0, 1000)
    return { success: true, recipe: truncatedText }
  } catch (error) {
    console.error("Error generating recipe:", error)
    return { success: false, error: "Failed to generate recipe. Please try again." }
  }
}

