"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { generateRecipe } from "../actions/generateRecipe"
import { usePreferences } from "../context/PreferencesContext"
import { ScrollArea } from "@/components/ui/scroll-area"

type Message = {
  role: "user" | "assistant"
  content: string
}

export default function ResultsPage() {
  const router = useRouter()
  const { preferences } = usePreferences()
  const [messages, setMessages] = useState<Message[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchRecipe = async () => {
    setIsLoading(true)
    setError(null)

    const result = await generateRecipe(preferences)

    if (result.success) {
      setMessages([
        { role: "assistant", content: "Based on your preferences, here's a recipe suggestion:" },
        { role: "assistant", content: result.recipe },
      ])
    } else {
      setError(result.error)
    }
    setIsLoading(false)
  }

  useEffect(() => {
    if (!preferences.mealType || !preferences.mood) {
      router.push("/input")
      return
    }
    fetchRecipe()
  }, [preferences, router])

  return (
    <div className="min-h-screen flex flex-col p-4 md:p-6">
      <div className="max-w-2xl w-full mx-auto bg-background rounded-lg shadow-lg flex flex-col flex-grow">
        <h1 className="text-3xl font-bold p-6 text-center border-b">Bon Appet-AI</h1>

        <div className="flex-grow flex flex-col p-6">
          {isLoading ? (
            <div className="flex-grow flex flex-col items-center justify-center p-8">
              <div className="animate-pulse space-y-4 w-full">
                <div className="h-4 bg-primary/20 rounded w-3/4 mx-auto"></div>
                <div className="h-4 bg-primary/20 rounded w-1/2 mx-auto"></div>
                <div className="h-4 bg-primary/20 rounded w-2/3 mx-auto"></div>
              </div>
              <p className="mt-4 text-muted-foreground">Cooking up your personalized recipe...</p>
            </div>
          ) : error ? (
            <div className="flex-grow flex items-center justify-center">
              <p className="text-red-500">{error}</p>
            </div>
          ) : (
            <ScrollArea className="flex-grow -mx-6 px-6">
              <div className="space-y-4">
                {messages.map((message, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-lg ${
                      message.role === "user"
                        ? "bg-secondary text-secondary-foreground"
                        : "bg-primary text-primary-foreground"
                    }`}
                  >
                    {message.content.split("\n").map((line, i) => (
                      <p key={i} className="my-1 break-words">
                        {line}
                      </p>
                    ))}
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </div>

        <div className="border-t p-6">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <Button onClick={() => router.back()} variant="outline" className="w-full sm:w-auto">
              Previous
            </Button>
            <Button
              onClick={fetchRecipe}
              className="w-full sm:w-auto bg-accent text-white hover:bg-accent/90"
              disabled={isLoading}
            >
              {isLoading ? "Generating..." : "Regenerate Recipe"}
            </Button>
            <Button onClick={() => router.push("/")} variant="outline" className="w-full sm:w-auto">
              Start Again
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

