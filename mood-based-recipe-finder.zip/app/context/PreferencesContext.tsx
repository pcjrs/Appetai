"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

type Preferences = {
  mealType: string
  mood: string
  ingredients: string
  selectedTools: string[]
}

type PreferencesContextType = {
  preferences: Preferences
  setPreferences: (preferences: Preferences) => void
}

const PreferencesContext = createContext<PreferencesContextType | undefined>(undefined)

export function PreferencesProvider({ children }: { children: ReactNode }) {
  const [preferences, setPreferences] = useState<Preferences>({
    mealType: "",
    mood: "",
    ingredients: "",
    selectedTools: [],
  })

  return <PreferencesContext.Provider value={{ preferences, setPreferences }}>{children}</PreferencesContext.Provider>
}

export function usePreferences() {
  const context = useContext(PreferencesContext)
  if (context === undefined) {
    throw new Error("usePreferences must be used within a PreferencesProvider")
  }
  return context
}

