"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { Clock, ChefHat, Utensils, Heart } from "lucide-react"
import { usePreferences } from "../context/PreferencesContext"

const mealTypes = [
  {
    icon: <ChefHat className="w-8 h-8 mb-2 text-primary" />,
    name: "Quick & Easy",
    description: "Simple recipes ready in 30 minutes or less",
  },
  {
    icon: <Heart className="w-8 h-8 mb-2 text-primary" />,
    name: "Comfort Food",
    description: "Hearty, satisfying meals for cozy days",
  },
  {
    icon: <Utensils className="w-8 h-8 mb-2 text-primary" />,
    name: "Gourmet",
    description: "Elevated dishes for special occasions",
  },
  {
    icon: <Clock className="w-8 h-8 mb-2 text-primary" />,
    name: "Meal Prep",
    description: "Plan ahead with these batch-cooking recipes",
  },
]

const moods = [
  { emoji: "😃", name: "Happy" },
  { emoji: "😴", name: "Tired" },
  { emoji: "🍽️", name: "Adventurous" },
  { emoji: "🛋️", name: "Lazy" },
]

const kitchenTools = ["Oven", "Microwave", "Blender", "Air Fryer"]

export default function UserInputPage() {
  const router = useRouter()
  const { preferences, setPreferences } = usePreferences()
  const [step, setStep] = useState(1)
  const [mealType, setMealType] = useState("")
  const [mood, setMood] = useState("")
  const [ingredients, setIngredients] = useState("")
  const [selectedTools, setSelectedTools] = useState<string[]>([])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    router.push("/results")
  }

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-4">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">What types of meals do you prefer?</h2>
              <p className="text-muted-foreground">Choose the style that matches your cooking mood today.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {mealTypes.map((type) => (
                <Card
                  key={type.name}
                  className={`cursor-pointer transition-all hover:border-primary ${
                    mealType === type.name ? "border-primary bg-primary/5" : ""
                  }`}
                  onClick={() => {
                    setMealType(type.name)
                    setPreferences({ ...preferences, mealType: type.name })
                  }}
                >
                  <CardContent className="flex flex-col items-center text-center p-6">
                    {type.icon}
                    <h3 className="font-semibold mb-1">{type.name}</h3>
                    <p className="text-sm text-muted-foreground">{type.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )
      case 2:
        return (
          <div className="space-y-4">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">How are you feeling today?</h2>
              <p className="text-muted-foreground">Your mood influences the perfect recipe match.</p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {moods.map((m) => (
                <Card
                  key={m.name}
                  className={`cursor-pointer transition-all hover:border-primary ${
                    mood === m.name ? "border-primary bg-primary/5" : ""
                  }`}
                  onClick={() => {
                    setMood(m.name)
                    setPreferences({ ...preferences, mood: m.name })
                  }}
                >
                  <CardContent className="flex flex-col items-center p-6">
                    <span className="text-4xl mb-2">{m.emoji}</span>
                    <span className="font-medium">{m.name}</span>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )
      case 3:
        return (
          <div className="space-y-4">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold mb-2">What ingredients do you have?</h2>
              <p className="text-muted-foreground">Let's work with what's in your kitchen.</p>
            </div>
            <div className="max-w-md mx-auto">
              <Label htmlFor="ingredients">Available Ingredients</Label>
              <Input
                id="ingredients"
                value={ingredients}
                onChange={(e) => {
                  setIngredients(e.target.value)
                  setPreferences({ ...preferences, ingredients: e.target.value })
                }}
                placeholder="Enter ingredients, separated by commas"
                className="glassmorphism"
              />
              <div className="mt-8">
                <Label className="mb-4">Kitchen Tools Available</Label>
                <div className="grid grid-cols-2 gap-4">
                  {kitchenTools.map((tool) => (
                    <Card
                      key={tool}
                      className={`cursor-pointer transition-all hover:border-primary ${
                        selectedTools.includes(tool) ? "border-primary bg-primary/5" : ""
                      }`}
                      onClick={() => {
                        setSelectedTools(
                          selectedTools.includes(tool)
                            ? selectedTools.filter((t) => t !== tool)
                            : [...selectedTools, tool],
                        )
                        setPreferences({
                          ...preferences,
                          selectedTools: selectedTools.includes(tool)
                            ? selectedTools.filter((t) => t !== tool)
                            : [...selectedTools, tool],
                        })
                      }}
                    >
                      <CardContent className="p-4 text-center">{tool}</CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )
    }
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-4xl font-bold mb-12 text-center">What's Cooking?</h1>
      <form onSubmit={handleSubmit} className="space-y-8">
        {renderStep()}
        <div className="flex justify-between mt-8">
          {step > 1 && (
            <Button type="button" variant="outline" onClick={() => setStep(step - 1)}>
              Previous
            </Button>
          )}
          {step < 3 ? (
            <Button
              type="button"
              className="ml-auto"
              onClick={() => {
                if (step === 1 && preferences.mealType) {
                  setStep(2)
                } else if (step === 2 && preferences.mood) {
                  setStep(3)
                }
              }}
              disabled={(step === 1 && !preferences.mealType) || (step === 2 && !preferences.mood)}
            >
              Continue
            </Button>
          ) : (
            <Button
              type="submit"
              className="ml-auto bg-accent text-white hover:bg-accent/90"
              disabled={!preferences.ingredients || preferences.selectedTools.length === 0}
            >
              Get Recipe Recommendations
            </Button>
          )}
        </div>
      </form>
    </div>
  )
}

