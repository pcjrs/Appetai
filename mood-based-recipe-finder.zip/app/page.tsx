import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div
      className="flex flex-col items-center justify-center min-h-screen bg-cover bg-center bg-no-repeat relative"
      style={{
        backgroundImage: `url('https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-odhQfJoYGpKiFf7WBQkmLYaXd2IWUV.png')`,
        backgroundPosition: "left center",
        backgroundColor: "#ffffff",
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/80 to-white"></div>
      <div className="relative z-10 max-w-2xl ml-auto mr-8 p-8 text-right">
        <h1 className="text-5xl font-bold mb-6 text-gray-900">Appet.ai</h1>
        <p className="text-xl mb-8 text-gray-700">
          Your AI-powered mood-based recipe finder. Discover personalized recipes tailored to your mood, ingredients,
          and kitchen tools!
        </p>
        <Link href="/input">
          <Button size="lg" className="bg-accent text-white hover:bg-accent/90">
            Get Started
          </Button>
        </Link>
      </div>
    </div>
  )
}

