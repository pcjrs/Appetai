import "./globals.css"
import { Inter } from "next/font/google"
import { PreferencesProvider } from "./context/PreferencesContext"
import type React from "react" // Added import for React

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Appet.ai",
  description: "Find recipes based on your mood and available ingredients",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} min-h-screen`}>
        <PreferencesProvider>{children}</PreferencesProvider>
      </body>
    </html>
  )
}

